<div class="login_box">
    <div class="login">
        <h2 class="text-center">Creation de compte</h1>

        <form action="" method="post" class="needs-validated">
            <label class="form-label" for="email">Adresse Email</label>
            <div class="form-group">
                <input class="form-control" type="email" name="user" id="user" class="form-controle">
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Mot de passe</label>
                <input class="form-control" type="password" name="pwd" id="pwd" class="form-controle">
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Confirmation du Mot de passe</label>
                <input class="form-control" type="password" name="confirmPassword" id="confirmPassword" class="form-controle">
            </div>
            <div class="form-group">
            <input type="submit" name="ajouter" value="Créer mon compte" class="btn btn-success w-100">
            </div>
        </form>
    </div>
</div>