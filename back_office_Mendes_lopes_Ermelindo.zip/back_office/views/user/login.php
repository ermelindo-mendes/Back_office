<div class="login_box">
    <div class="login">
        <h1 class="text-center">Connexion</h1>

        <form action="" method="post" class="needs-validated">

            <div class="form-group">
                <label class="form-label" for="email">Adresse Email</label>
                <input class="form-control" type="email" name="user" id="user" class="form-controle" placeholder="Entrez votre email" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Mot de passe</label>
                <input class="form-control" type="password" name="pwd" id="pwd" class="form-controle" placeholder="Entrez votre mot de passe" required>
            </div>
            <div class="form-group">
            <input type="submit" name="ajouter" value="Se connecter" class="btn btn-success w-100">
            </div>
        </form>
    </div>
</div>